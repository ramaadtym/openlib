<?php $__env->startSection('tbl_thisweek'); ?>
    <div class="table-responsive">
        <table class="table table-hover table-striped table-bordered" id="example">
            <thead>
            <tr>
                <th></th>
                <th>Nama</th>
                <th>Poin</th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <td>1</td>
                <td>Ana</td>
                <td>150 Pts</td>
            </tr>
            <tr>
                <td>2</td>
                <td>Doni</td>
                <td>100 Pts</td>
            </tr>
            <tr>
                <td>3</td>
                <td>Dodit</td>
                <td>80 Pts</td>
            </tr>
            <tr>
                <td>4</td>
                <td>Yati</td>
                <td>60 Pts</td>
            </tr>
            <tr>
                <td>5</td>
                <td>Danang</td>
                <td>30 Pts</td>
            </tr>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>