<?php $__env->startSection('judul_bar','Open Library -'); ?>
<?php $__env->startSection('dash_content'); ?>
    <div class="container-fluid">
        <div class="col-lg-12">
            <h2 class="katalog"> <?php echo e($title); ?></h2>
            <?php if(count($errors) > 0): ?>
                <div class="col-lg-10">
                    <ul class="error" id="error">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
        </div>
        <div class="col-lg-10 konten">
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-info">
                        <div class="panel-heading text">Katalog</div>
                        <div class="panel-body">
                            <div class="col-lg-6">
                                <h4><?php echo e($title); ?></h4>

                            </div>
                            <div class="col-lg-6">
                                <?php if($item->gbr == ""): ?>
                                    <img src="/images/default.jpg" class="pull-right img-responsive">
                                <?php else: ?>
                                    <img src="/images/buku/<?php echo e($item->gbr); ?>" class="pull-right img-responsive">
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-info">
                        <div class="panel-heading text">Ulasan untuk <?php echo e($item->judul); ?></div>
                        <div class="panel-body">
                            <div class="col-lg-5">
                                <form method="post" action="/ulas">
                                    <div class="form-group">
                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                        <input type="hidden" name="jdlbook" value="<?php echo e($item->judul); ?>">
                                        <label for="sel1">Rating:</label>
                                        <select name="rate" class="form-control enambelas" id="sel1">
                                            <option value="1">Sangat Buruk</option>
                                            <option value="2">Buruk</option>
                                            <option value="3" selected="selected">Biasa saja</option>
                                            <option value="4">Bagus</option>
                                            <option value="5">Sangat Bagus</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="sel1">Subjek * :</label>
                                        <input type="text" name="subjek" value="<?php echo e(old('subjek')); ?>" class="form-control enambelas">
                                    </div>
                                    <div class="form-group">
                                        <label for="sel1">Ulasan* :</label>
                                        <textarea class="form-control enambelas" name="ulasan" rows="5" id="comment"><?php echo e(old('ulasan')); ?></textarea>
                                    </div>
                                    <button class="btn btn-default">Kirim Ulasan</button>
                                </form>
                            </div>
                            <div class="col-lg-7">
                                <p>Ulasan <?php echo e($item->judul); ?></p>
                                <ol>
                                    <?php $__currentLoopData = $review; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ulasan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="komentar">
                                            <b><?php echo e($ulasan->subjek); ?></b> by <?php echo e($ulasan->nama); ?> <span class="rate<?php echo e($ulasan->rating); ?>"></span>
                                            <p><?php echo e($ulasan->ulasan); ?></p>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.masterdashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>